<script>
export default {
  scrollToTop: true,
  data: () => {
    return {
      // @todo
    };
  },
  computed: {
    // @todo
  },
};
</script>

<template>
  <div class="container mx-auto">
    <ProjectsGrid />
  </div>
</template>

<style lang="scss" scoped></style>
