<template>
  <button>{{ title }}</button>
</template>

<script>
export default {
  props: ["title"],
  data: () => {
    return {
      // @todo
    };
  },
};
</script>

<style lang="scss" scoped></style>
